#include "arbol.h"

/**
 * @brief 
 * 
 * @param hab 
 * @return NodoArbol* 
 */
// Crea un nodo individual reservando memoria
NodoArbol* crear_nodo(Habitacion *hab) {
    if(hab == NULL){
        return NULL;
    }
    
    NodoArbol *nuevo = malloc(sizeof(NodoArbol));
    if(nuevo == NULL){
        printf("Error: No se pudo asignar memoria para el nodo del arbol.\n");
        return NULL;
    }
    nuevo->habitacion = hab;
    nuevo->izq = NULL;
    nuevo->der = NULL;
    return nuevo;
}

/**
 * @brief 
 * 
 * @param raiz 
 * @param hab 
 * @return NodoArbol* 
 */
// Inserción recursiva basada en el ID
NodoArbol* insertar_nodo(NodoArbol *raiz, Habitacion *hab) {
    if(hab == NULL){
        return raiz;
    }

    // Si el árbol o subárbol está vacío, se crea el primer nodo
    if(raiz == NULL){
        return crear_nodo(hab);
    }
    if(hab->id < raiz->habitacion->id){
        raiz->izq = insertar_nodo(raiz->izq, hab);
    }else if(hab->id > raiz->habitacion->id){
        raiz->der = insertar_nodo(raiz->der, hab);
    }else{
        printf("Advertencia: La habitacion con ID %d ya existe en el arbol.\n", hab->id);
    }

    return raiz;
}

// Búsqueda en O(log n) promedio
Habitacion* buscar_nodo(NodoArbol *raiz, int id){
    if(raiz == NULL){
        return NULL; // No encontrada
    }
    if(id == raiz->habitacion->id){
        return raiz->habitacion;
    }
    if(id < raiz->habitacion->id){
        return buscar_nodo(raiz->izq, id);
    }else{
        return buscar_nodo(raiz->der, id);
    }
}

// Función auxiliar para encontrar el nodo con el ID menor (usado en la eliminación de 2 hijos)
NodoArbol* obtener_minimo(NodoArbol *nodo){
    NodoArbol *actual = nodo;
    while (actual && actual->izq != NULL){
        actual = actual->izq;
    }
    return actual;
}

// Eliminación contemplando los 3 casos
NodoArbol* eliminar_nodo(NodoArbol *raiz, int id){
    if(raiz == NULL){
        return NULL;
    }
    if(id < raiz->habitacion->id){
        raiz->izq = eliminar_nodo(raiz->izq, id);
    }else if(id > raiz->habitacion->id){
        raiz->der = eliminar_nodo(raiz->der, id);
    }else{
        if(raiz->izq == NULL){
            NodoArbol *temp = raiz->der;
            liberar_habitacion(raiz->habitacion);
            free(raiz);
            return temp;
        } 
        else if(raiz->der == NULL){
            NodoArbol *temp = raiz->izq;
            liberar_habitacion(raiz->habitacion);
            free(raiz);
            return temp;
        }
        NodoArbol *temp = obtener_minimo(raiz->der);
        liberar_habitacion(raiz->habitacion);
        raiz->habitacion = temp->habitacion;
        raiz->der = eliminar_nodo(raiz->der, temp->habitacion->id);
    }
    return raiz;
}

void recorrer_inorden(NodoArbol *raiz){
    if (raiz == NULL){
        return;
    }
    recorrer_inorden(raiz->izq);
    mostrar_habitacion(raiz->habitacion); 
    recorrer_inorden(raiz->der);
}

void liberar_arbol(NodoArbol *raiz) {
    if(raiz == NULL){
        return;
    }
    liberar_arbol(raiz->izq);
    liberar_arbol(raiz->der);
    liberar_habitacion(raiz->habitacion);
    free(raiz);
}
