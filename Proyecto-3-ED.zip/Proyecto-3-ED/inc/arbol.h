/**
 * @file arbol.h
 * @author Benjamin Hernandez
 * @brief 
 * @date 2026-11-07
 */
#ifndef ARBOL_H
#define ARBOL_H

#include <stdio.h>
#include <stdlib.h>
#include "arbol.h"
#include "habitacion.h"

// Estructura de cada nodo del ABB
typedef struct NodoArbol {
    Habitacion *habitacion;   
    struct NodoArbol *izq;    
    struct NodoArbol *der;
} NodoArbol;

// Funciones del Árbol
NodoArbol* crear_nodo(Habitacion *hab);
NodoArbol* insertar_nodo(NodoArbol *raiz, Habitacion *hab);
Habitacion* buscar_nodo(NodoArbol *raiz, int id);
NodoArbol* obtener_minimo(NodoArbol *nodo);
NodoArbol* eliminar_nodo(NodoArbol *raiz, int id);
void recorrer_inorden(NodoArbol *raiz);
void liberar_arbol(NodoArbol *raiz);

#endif